package com.mycompany.negocio;

import com.mycompany.entidades.Materia;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class MateriaService {

    @PersistenceContext
    private EntityManager entityManager;

    public void saveMateria(Materia materia) {
        entityManager.persist(materia);
    }

    public void editMateria(Materia materia) {
        entityManager.merge(materia);
    }

    public void deleteMateria(Materia materia) {
        Materia materiaToDelete = entityManager.merge(materia);
        entityManager.remove(materiaToDelete);
    }

    public List<Materia> getMaterias() {
        return entityManager.createQuery("SELECT m FROM Materia m", Materia.class).getResultList();
    }
}
