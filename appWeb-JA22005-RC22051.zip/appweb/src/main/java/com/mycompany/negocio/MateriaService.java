package com.mycompany.negocio;

import com.mycompany.entidades.Materia;
import java.util.ArrayList;
import java.util.List;

public class MateriaService {
    private List<Materia> materias = new ArrayList<>();

    // Método para guardar una materia
    public void saveMateria(Materia materia) {
        // Lógica para guardar la materia en la base de datos o en alguna estructura de datos
        materias.add(materia);
    }

    // Método para editar una materia
    public void editMateria(Materia materia) {
        // Lógica para editar la materia en la base de datos o en alguna estructura de datos
        for (int i = 0; i < materias.size(); i++) {
            if (materias.get(i).getId().equals(materia.getId())) {
                materias.set(i, materia);
                break;
            }
        }
    }

    // Método para eliminar una materia
    public void deleteMateria(Materia materia) {
        // Lógica para eliminar la materia de la base de datos o de alguna estructura de datos
        materias.removeIf(m -> m.getId().equals(materia.getId()));
    }

    // Método para obtener todas las materias
    public List<Materia> getMaterias() {
        // Lógica para obtener todas las materias de la base de datos o de alguna estructura de datos
        return materias;
    }
}
